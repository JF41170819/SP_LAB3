$(document).ready(function(){
    $("#loginForm").bootstrapValidator({
        message:"Default",
        feedbackIcons:{
            valid:"glyphicon glyphicon-ok",
            invalid:"glyphicon glyphicon-remove",
            validating:"glyphicon glyphicon-refresh"
        },
        fields:{
            usuario:{
                validators:{
                    notEmpty:{
                        message:"El campo email no puede estar vacío"
                    },
                    emailAddress:{
						message:"E-mail invalido"
					}
                }
            },
            password:{
                validators:{
                    notEmpty:{
                        message:"El campo password no puede estar vacío"
                    },
                    stringLength: {
                        min: 4,
                        max: 8,
                        message: 'Por favor, ingrese entre 4 y 8 caracteres'
                    }
                }
            }
        }
    })
});