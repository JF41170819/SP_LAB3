window.onload = function () {
    if (!localStorage.getItem('usuarios')) {
        var usuarios = [{
                "correo": "a@a.com",
                "clave": "1234",
                "nombre": "Juan",
                "apellido": "Figueiras",
                "legajo": 1,
                "perfil": "super_admin",
                "foto": "jf.jpg"
            },
            {
                "correo": "b@b.com",
                "clave": "5678",
                "nombre": "Carlos",
                "apellido": "Vargas",
                "legajo": 2,
                "perfil": "user",
                "foto": "cv.jpg"
            },
            {
                "correo": "c@c.com",
                "clave": "91011",
                "nombre": "Jhon",
                "apellido": "Velazquez",
                "legajo": 3,
                "perfil": "user",
                "foto": "jv.jpg"
            },
            {
                "correo": "d@d.com",
                "clave": "121314",
                "nombre": "Facundo",
                "apellido": "Cabral",
                "legajo": 4,
                "perfil": "admin",
                "foto": "fc.jpg"
            },
            {
                "correo": "e@e.com",
                "clave": "151617",
                "nombre": "Jahseh",
                "apellido": "Onfroy",
                "legajo": 5,
                "perfil": "admin",
                "foto": "jo.jpg"
            },];
        localStorage.setItem('usuarios', JSON.stringify(usuarios));
        console.log("Usuarios: \n" + localStorage.getItem('usuarios'));
    }
    else {
        console.log("Ya se han cargado previamente los siguientes usuarios: \n" + localStorage.getItem('usuarios'));
    }
};
var SegundoParcial;
(function (SegundoParcial) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.Enviar = function () {
            //console.log('Entro!');
            var usuario = document.getElementById('usuario').value;
            var password = document.getElementById('password').value;
            var usuarios = localStorage.getItem('usuarios');
            usuarios = JSON.parse(usuarios);
            var esta = false;
            usuarios.forEach(function (obj) {
                console.log(obj);
                if (obj.correo == usuario && obj.clave == password) {
                    esta = true;
                    console.log('El usuario esta!');
                    window.location.assign('./principal.html');
                }
            });
            if (!esta) {
                console.log('El usuario no esta!');
                document.getElementById('Error').className = 'alert alert-danger';
                //(<HTMLDivElement>document.getElementById('Error')).innerHTML = '<div class="alert alert-danger" role="alert">Usuario no registrado</div>';
            }
        };
        Manejadora.EnviarRegistro = function () {
            var apellido = document.getElementById('apellido').value;
            var nombre = document.getElementById('nombre').value;
            var email = document.getElementById('usuario').value;
            var legajo = document.getElementById('legajo').value;
            var perfil = document.getElementById('perfil').value;
            var foto = document.getElementById('foto');
            var password = document.getElementById('password').value;
            var fotoReal = foto.files[0].name;
            var usuarios = localStorage.getItem('usuarios');
            usuarios = JSON.parse(usuarios);
            var esta = false;
            usuarios.forEach(function (obj) {
                //console.log(obj);
                if (obj.correo == email && obj.clave == password) {
                    esta = true;
                    console.log('El usuario ya esta!');
                    document.getElementById('Error').innerHTML = '<div class="alert alert-danger" role="alert">ERROR, el usuario ya se encuentra registrado!</div>';
                }
            });
            if (!esta) {
                var usr = {
                    "correo": email,
                    "clave": password,
                    "nombre": nombre,
                    "apellido": apellido,
                    "legajo": legajo,
                    "perfil": perfil,
                    "foto": fotoReal
                };
                usuarios.push(usr);
                localStorage.setItem('usuarios', JSON.stringify(usuarios));
                console.log(localStorage.getItem('usuarios'));
                window.location.assign('./login.html');
            }
        };
        return Manejadora;
    }());
    SegundoParcial.Manejadora = Manejadora;
})(SegundoParcial || (SegundoParcial = {}));
