$(document).ready(function(){
    $("#loginForm").bootstrapValidator({
        message:"Default",
        feedbackIcons:{
            valid:"glyphicon glyphicon-ok",
            invalid:"glyphicon glyphicon-remove",
            validating:"glyphicon glyphicon-refresh"
        },
        fields:{
            apellido:{
                validators:{
                    notEmpty:{
                        message:"El campo apellido no puede estar vacío"
                    },
                    stringLength:{
                        min: 1,
                        max: 15,
						message:"Error, el rango de caracteres para el apellido es de 1 a 15"
					}
                }
            },
            nombre:{
                validators:{
                    notEmpty:{
                        message:"El campo nombre no puede estar vacío"
                    },
                    stringLength:{
                        min: 1,
                        max: 10,
                        message: 'Error, el rango de caracteres para el nombre es de 1 a 8'
                    }
                }
            },
            usuario:{
                validators:{
                    notEmpty:{
                        message:"El campo email no puede estar vacío"
                    },
                    emailAddress:{
						message:"E-mail invalido"
					}
                }
            },
            legajo:{
                validators:{
                    notEmpty:{
                        message:"El campo legajo no puede estar vacío"
                    },
                    stringLength:{
                        min: 3,
                        max: 6,
						message:"Error, el legajo debe tener entre 3 y 6 digitos"
                    },
                    regexp:{
						regexp: /^[0-9]+$/,
						message: "El caracter debe ser un entero"
					}
                }
            },
            foto:{
                validators:{
                    notEmpty:{
                        message:"Error, Cargue una foto"
                    },
					file:{
						extension: 'jpg,png',
						message: "Error, la imagen debe ser jpg o png"
					},
                }
            },
            password:{
                validators:{
                    notEmpty:{
                        message:"El campo password no puede estar vacío"
                    },
					stringLength:{
						min: 4,
						max: 8,
						message: "La password debe tener entre 4 y 8 caracteres"
					},
					identical:{
						field: 'password2',
						message: "Error, las contraseñas no coinciden"
					}
                }
            },
            password2:{
                validators:{
                    notEmpty:{
                        message:"El campo password no puede estar vacío"
                    },
					stringLength:{
						min: 4,
						max: 8,
						message: "La password debe tener entre 4 y 8 caracteres"
					},
					identical:{
						field: 'password',
						message: "Error, las contraseñas no coinciden"
					}
                }
            }
        }
    })
});