window.onload = function (): void {



    var usuarios : any = localStorage.getItem('usuarios');

    usuarios = JSON.parse(usuarios);

    var html =`<h1>Bootstrap Basic Table</h1>  
    <!--Bootstrap Basic Table using .table class-->  
    <table class="table">  
        <thead>  
            <tr>
                <th>CORREO</th>  
                <th>NOMBRE</th>  
                <th>APELLIDO</th>  
                <th>PERFIL</th>
                <th>LEGAJO</th>
                <th>FOTO</th>  
            </tr>  
        </thead>  
        <tbody>`;

    if(localStorage.getItem("admin") == "true")
    {
        usuarios.forEach((obj : any) => 
        {
            //console.log(obj);
    
            html+='<tr><td>' + obj.correo + '</td>';
            html+='<td>' + obj.nombre + '</td>';
            html+='<td>' + obj.apellido + '</td>';
            html+='<td>' + obj.perfil + '</td>';
            html+='<td>' + obj.legajo + '</td>';
            html+='<td><img src="./fotos/' + obj.foto + '" height="42" width="42"></td>';
            html+='<td><button class="btn btn-primary btn-block" id="btnEliminar" onclick="SegundoParcial.Manejadora.Eliminar(' + obj.correo + ')"> Eliminar</button> </td></tr>';
    
        });
    
    }
    else
    {
    usuarios.forEach((obj : any) => 
    {
        //console.log(obj);

        html+='<tr><td>' + obj.correo + '</td>';
        html+='<td>' + obj.nombre + '</td>';
        html+='<td>' + obj.apellido + '</td>';
        html+='<td>' + obj.perfil + '</td>';
        html+='<td>' + obj.legajo + '</td>';
        html+='<td><img src="./fotos/' + obj.foto + '" height="42" width="42"></td></tr>';
        



    });
    }

    html+='</tbody></table></div>';

    console.log(html);
    
    (<HTMLDivElement>document.getElementById('tabla')).innerHTML = html;
};