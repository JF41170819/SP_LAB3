window.onload = function () {
    var usuarios = localStorage.getItem('usuarios');
    usuarios = JSON.parse(usuarios);
    var html = "<h1>Bootstrap Basic Table</h1>  \n    <!--Bootstrap Basic Table using .table class-->  \n    <table class=\"table\">  \n        <thead>  \n            <tr>\n                <th>CORREO</th>  \n                <th>NOMBRE</th>  \n                <th>APELLIDO</th>  \n                <th>PERFIL</th>\n                <th>LEGAJO</th>\n                <th>FOTO</th>  \n            </tr>  \n        </thead>  \n        <tbody>";
    if (localStorage.getItem("admin") == "true") {
        usuarios.forEach(function (obj) {
            //console.log(obj);
            html += '<tr><td>' + obj.correo + '</td>';
            html += '<td>' + obj.nombre + '</td>';
            html += '<td>' + obj.apellido + '</td>';
            html += '<td>' + obj.perfil + '</td>';
            html += '<td>' + obj.legajo + '</td>';
            html += '<td><img src="./fotos/' + obj.foto + '" height="42" width="42"></td>';
            html += '<td><button class="btn btn-primary btn-block" id="btnEliminar" onclick="SegundoParcial.Manejadora.Eliminar(' + obj.correo + ')"> Eliminar</button> </td></tr>';
        });
    }
    else {
        usuarios.forEach(function (obj) {
            //console.log(obj);
            html += '<tr><td>' + obj.correo + '</td>';
            html += '<td>' + obj.nombre + '</td>';
            html += '<td>' + obj.apellido + '</td>';
            html += '<td>' + obj.perfil + '</td>';
            html += '<td>' + obj.legajo + '</td>';
            html += '<td><img src="./fotos/' + obj.foto + '" height="42" width="42"></td></tr>';
        });
    }
    html += '</tbody></table></div>';
    console.log(html);
    document.getElementById('tabla').innerHTML = html;
};
