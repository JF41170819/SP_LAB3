window.onload = function (): void {

    if(!localStorage.getItem('usuarios'))
    {
        var usuarios = [{
            "correo": "a@a.com",
            "clave": "1234",
            "nombre": "Juan",
            "apellido": "Figueiras",
            "legajo": 1,
            "perfil": "super_admin",
            "foto": "jf.jpg"
        },
        {
            "correo": "b@b.com",
            "clave": "5678",
            "nombre": "Carlos",
            "apellido": "Vargas",
            "legajo": 2,
            "perfil": "user",
            "foto": "cv.jpg"
        },
        {
            "correo": "c@c.com",
            "clave": "91011",
            "nombre": "Jhon",
            "apellido": "Velazquez",
            "legajo": 3,
            "perfil": "user",
            "foto": "jv.jpg"
        },
        {
            "correo": "d@d.com",
            "clave": "121314",
            "nombre": "Facundo",
            "apellido": "Cabral",
            "legajo": 4,
            "perfil": "admin",
            "foto": "fc.jpg"
        },
        {
            "correo": "e@e.com",
            "clave": "151617",
            "nombre": "Jahseh",
            "apellido": "Onfroy",
            "legajo": 5,
            "perfil": "admin",
            "foto": "jo.jpg"
        },]

        localStorage.setItem('usuarios', JSON.stringify(usuarios));
        console.log("Usuarios: \n" + localStorage.getItem('usuarios'));
    }
    else
    {
        console.log("Ya se han cargado previamente los siguientes usuarios: \n" + localStorage.getItem('usuarios'));
    }


};
namespace SegundoParcial{

    export class Manejadora{

        public static Enviar()
        {
            //console.log('Entro!');
            var usuario : any = (<HTMLInputElement>document.getElementById('usuario')).value;
            var password : any = (<HTMLInputElement>document.getElementById('password')).value;

            var usuarios : any = localStorage.getItem('usuarios');

            usuarios = JSON.parse(usuarios);

            var esta = false;

            usuarios.forEach((obj : any) => 
            {
                console.log(obj);

                if (obj.correo == usuario && obj.clave == password) 
                {
                    esta = true;
                    console.log('El usuario esta!');

                    if(obj.perfil == 'admin')
                    {
                        localStorage.setItem('admin', 'true');
                    }
                    else
                    {
                        localStorage.setItem('admin', 'false');
                    }
                    
                    window.location.assign('./principal.html');
                }

            });

            if (!esta) {
                console.log('El usuario no esta!');
                (<HTMLDivElement>document.getElementById('Error')).className = 'alert alert-danger';
                //(<HTMLDivElement>document.getElementById('Error')).innerHTML = '<div class="alert alert-danger" role="alert">Usuario no registrado</div>';
            }
        }

        public static EnviarRegistro()
        {
            var apellido : any = (<HTMLInputElement>document.getElementById('apellido')).value;
            var nombre : any = (<HTMLInputElement>document.getElementById('nombre')).value;
            var email : any = (<HTMLInputElement>document.getElementById('usuario')).value;
            var legajo : any = (<HTMLInputElement>document.getElementById('legajo')).value;
            var perfil : any = (<HTMLSelectElement>document.getElementById('perfil')).value;
            var foto : any = <HTMLInputElement>document.getElementById('foto');
            var password : any = (<HTMLInputElement>document.getElementById('password')).value;

            var fotoReal = foto.files[0].name;

            var usuarios : any = localStorage.getItem('usuarios');

            usuarios = JSON.parse(usuarios);

            var esta = false;

            usuarios.forEach((obj : any) => 
            {
                //console.log(obj);

                if (obj.correo == email && obj.clave == password) 
                {
                    esta = true;
                    console.log('El usuario ya esta!');
                    (<HTMLDivElement>document.getElementById('Error')).innerHTML = '<div class="alert alert-danger" role="alert">ERROR, el usuario ya se encuentra registrado!</div>';
                }

            });

            if(!esta)
            {
                var usr = {
                    "correo": email,
                    "clave": password,
                    "nombre": nombre,
                    "apellido": apellido,
                    "legajo": legajo,
                    "perfil": perfil,
                    "foto": fotoReal
                };

                usuarios.push(usr);

                localStorage.setItem('usuarios',  JSON.stringify(usuarios));
                console.log(localStorage.getItem('usuarios'));
                window.location.assign('./login.html');
            }

        }

        public static Eliminar(correo : any)
        {
            console.log("entra");
            var usuarios : any = localStorage.getItem('usuarios');
    
            usuarios = JSON.parse(usuarios);

            var newUsuarios : any = "";
    
            usuarios.forEach((obj : any) => 
            {
                
                if(obj.correo != correo)
                {
                    var usr = {
                        "correo": obj.correo,
                        "clave": obj.password,
                        "nombre": obj.nombre,
                        "apellido": obj.apellido,
                        "legajo": obj.legajo,
                        "perfil": obj.perfil,
                        "foto": obj.foto,
                    };

                    newUsuarios.push(usr);
                }

                
            });
            console.log(newUsuarios);
            localStorage.setItem('usuarios',  JSON.stringify(newUsuarios));
            console.log(localStorage.getItem('usuarios'));
        }
    }
}